// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "HealthUI.generated.h"

/**
 * 
 */
UCLASS()
class MYPROJECTDEMO1_API UHealthUI : public UUserWidget
{
	GENERATED_BODY()
};
