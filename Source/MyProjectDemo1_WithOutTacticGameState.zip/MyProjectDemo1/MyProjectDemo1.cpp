// Copyright Epic Games, Inc. All Rights Reserved.

#include "MyProjectDemo1.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, MyProjectDemo1, "MyProjectDemo1" );
