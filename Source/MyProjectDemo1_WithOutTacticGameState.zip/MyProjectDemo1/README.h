
Rules:
@Please write a short log to DevLog every time you update!
@Use Chinese to write DevLog

You can also change and add a little README file if you think it is necessary and feasible!
If I once said: Please add some English comments after writing the code, then please consider writing a README file.

Introduction:
This game is a JRPG game similar to Trails in the Sky.
Added GAS GameAbilitySystem development